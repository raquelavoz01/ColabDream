import 'package:flutter/material.dart';
void main() => runApp(ColabDreamApp());

class ColabDreamApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ColabDream',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: Color(0xFF6A0DAD),
        scaffoldBackgroundColor: Colors.white,
        colorScheme: ColorScheme.fromSwatch().copyWith(secondary: Color(0xFF8A2BE2)),
        textTheme: TextTheme(
          titleLarge: TextStyle(color: Colors.black87, fontSize: 22),
          bodyLarge: TextStyle(fontSize: 18, color: Colors.black87),
        ),
      ),
      home: InteractionScreen(),
    );
  }
}

class InteractionScreen extends StatefulWidget {
  @override
  _InteractionScreenState createState() => _InteractionScreenState();
}

class _InteractionScreenState extends State<InteractionScreen> {
  final _controller = TextEditingController();
  String _responseText = '';
  String _imageUrl = '';

  void _generateResponse() {
    setState(() {
      _responseText = 'A IA poética diz: “${_controller.text}”';
      _imageUrl = 'https://via.placeholder.com/300/6A0DAD/ffffff?text=ColabDream';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('ColabDream'),
        backgroundColor: Color(0xFF6A0DAD),
      ),
      body: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              decoration: InputDecoration(
                hintText: 'Conte uma ideia, imagem ou sensação…',
                filled: true, fillColor: Colors.white,
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: _generateResponse,
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFFFFD700),
                foregroundColor: Colors.black,
                padding: EdgeInsets.symmetric(vertical: 14, horizontal: 24),
              ),
              child: Text('Gerar Resposta'),
            ),
            SizedBox(height: 24),
            if (_responseText.isNotEmpty)
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      Text(_responseText, style: Theme.of(context).textTheme.bodyLarge),
                      SizedBox(height: 16),
                      if (_imageUrl.isNotEmpty)
                        Image.network(_imageUrl),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
